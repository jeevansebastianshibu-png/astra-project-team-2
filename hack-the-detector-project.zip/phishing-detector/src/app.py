"""
Live demo web app. Paste a URL, get an instant verdict — entirely offline,
zero network calls. Loads the lexical-only Random Forest model and explains
which of the 8 signals fired.

Usage:
    python src/app.py
    -> open http://127.0.0.1:5000
"""

import sys
from pathlib import Path

import joblib
import pandas as pd
from flask import Flask, jsonify, render_template, request

sys.path.insert(0, str(Path(__file__).resolve().parent))
from columns import FEATURE_EXPLANATIONS, LEXICAL_FEATURES
from lexical_features import extract

ROOT = Path(__file__).resolve().parent.parent
MODEL_PATH = ROOT / "models" / "lexical_model.pkl"

app = Flask(__name__, template_folder=str(ROOT / "templates"))

_model = None


def get_model():
    global _model
    if _model is None:
        if not MODEL_PATH.exists():
            raise FileNotFoundError(
                "models/lexical_model.pkl not found — run "
                "'python src/train_lexical_model.py' first."
            )
        _model = joblib.load(MODEL_PATH)
    return _model


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/analyze", methods=["POST"])
def analyze():
    data = request.get_json(force=True) or {}
    url = (data.get("url") or "").strip()
    if not url:
        return jsonify({"error": "Please paste a URL."}), 400

    features = extract(url)
    row = pd.DataFrame([[features[name] for name in LEXICAL_FEATURES]], columns=LEXICAL_FEATURES)

    model = get_model()
    proba = model.predict_proba(row)[0]
    classes = list(model.classes_)  # e.g. [-1, 1]
    phishing_proba = float(proba[classes.index(-1)])
    prediction = int(model.predict(row)[0])

    signals = []
    for name in LEXICAL_FEATURES:
        value = features[name]
        signals.append({
            "feature": name,
            "value": value,
            "flagged": value == -1,
            "suspicious": value == 0,
            "explanation": FEATURE_EXPLANATIONS.get(name, ""),
        })

    return jsonify({
        "url": url,
        "verdict": "phishing" if prediction == -1 else "legitimate",
        "phishing_probability": round(phishing_proba, 4),
        "signals": signals,
    })


if __name__ == "__main__":
    get_model()  # fail fast with a clear message if the model isn't trained yet
    app.run(debug=True, port=5000)
