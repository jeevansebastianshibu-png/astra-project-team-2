"""
Trains the lexical-only model: same Random Forest recipe as the full model,
but restricted to the 8 features that lexical_features.py can compute from
raw URL text alone. This is the model the Flask live demo actually loads.

Usage:
    python src/train_lexical_model.py
"""

import json
from pathlib import Path

import joblib
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score
from sklearn.model_selection import train_test_split

from columns import LEXICAL_FEATURES, TARGET

ROOT = Path(__file__).resolve().parent.parent
DATA_PATH = ROOT / "data" / "dataset.csv"
MODELS_DIR = ROOT / "models"
REPORTS_DIR = ROOT / "reports"
MODELS_DIR.mkdir(exist_ok=True)
REPORTS_DIR.mkdir(exist_ok=True)

RANDOM_STATE = 42


def main():
    df = pd.read_csv(DATA_PATH)
    X = df[LEXICAL_FEATURES]
    y = df[TARGET]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, stratify=y, random_state=RANDOM_STATE
    )

    model = RandomForestClassifier(n_estimators=200, random_state=RANDOM_STATE, n_jobs=-1)
    model.fit(X_train, y_train)
    preds = model.predict(X_test)

    metrics = {
        "features": LEXICAL_FEATURES,
        "n_features": len(LEXICAL_FEATURES),
        "test_accuracy": accuracy_score(y_test, preds),
        "precision": precision_score(y_test, preds, pos_label=1),
        "recall": recall_score(y_test, preds, pos_label=1),
        "f1_score": f1_score(y_test, preds, pos_label=1),
    }

    print("=== Lexical-only model (8 features, zero network calls) ===")
    for k, v in metrics.items():
        print(f"  {k}: {v}")

    joblib.dump(model, MODELS_DIR / "lexical_model.pkl")
    with open(MODELS_DIR / "lexical_model_meta.json", "w") as f:
        json.dump(metrics, f, indent=2)

    print(f"\nSaved model to models/lexical_model.pkl")


if __name__ == "__main__":
    main()
