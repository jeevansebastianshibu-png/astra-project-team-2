"""
Column / feature name definitions for the UCI Phishing Websites dataset.

The dataset (Mohammad, Thabtah & McCluskey, UCI ML Repository) encodes every
feature as a ternary value in {-1, 0, 1}:
    -1  -> looks phishy
     0  -> suspicious / can't tell
     1  -> looks legitimate
The target column, Result, uses the same convention (-1 = phishing, 1 = legitimate).
"""

# All 30 handcrafted features, in dataset order.
ALL_FEATURES = [
    "having_IP_Address",
    "URL_Length",
    "Shortining_Service",
    "having_At_Symbol",
    "double_slash_redirecting",
    "Prefix_Suffix",
    "having_Sub_Domain",
    "SSLfinal_State",
    "Domain_registeration_length",
    "Favicon",
    "port",
    "HTTPS_token",
    "Request_URL",
    "URL_of_Anchor",
    "Links_in_tags",
    "SFH",
    "Submitting_to_email",
    "Abnormal_URL",
    "Redirect",
    "on_mouseover",
    "RightClick",
    "popUpWidnow",
    "Iframe",
    "age_of_domain",
    "DNSRecord",
    "web_traffic",
    "Page_Rank",
    "Google_Index",
    "Links_pointing_to_page",
    "Statistical_report",
]

TARGET = "Result"

# The 8 features that can be computed from the URL string alone, with zero
# network calls. These are the only features available to the live demo,
# since a real-time paste-a-URL tool can't afford SSL lookups, WHOIS calls,
# or page-content parsing.
LEXICAL_FEATURES = [
    "having_IP_Address",
    "URL_Length",
    "Shortining_Service",
    "having_At_Symbol",
    "double_slash_redirecting",
    "Prefix_Suffix",
    "having_Sub_Domain",
    "HTTPS_token",
]

# Human-readable explanations shown in the live-demo UI when a signal fires.
FEATURE_EXPLANATIONS = {
    "having_IP_Address": "The domain is a raw IP address instead of a name.",
    "URL_Length": "The URL is unusually long, often used to hide the real destination.",
    "Shortining_Service": "The URL uses a link-shortening service, hiding the real domain.",
    "having_At_Symbol": "The URL contains an '@' symbol, a classic redirect trick.",
    "double_slash_redirecting": "A '//' appears deep in the path, which can silently redirect.",
    "Prefix_Suffix": "The domain has a hyphen stitched in, often mimicking a real brand.",
    "having_Sub_Domain": "The URL has an unusually high number of sub-domains.",
    "HTTPS_token": "The literal word 'https' appears inside the domain itself, not as the protocol.",
}
