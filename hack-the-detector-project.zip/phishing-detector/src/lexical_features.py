"""
Lexical (URL-text-only) feature extraction.

Re-implements 8 of the 30 UCI "Phishing Websites" features as pure
string/regex functions over the URL text. No DNS lookups, no HTTP
requests, no WHOIS calls — this is what lets the live demo answer
instantly and work fully offline.

Every function returns a value in {-1, 0, 1}, matching the dataset's
convention: -1 = looks phishy, 0 = suspicious, 1 = looks legitimate.
"""

import re
from urllib.parse import urlparse

SHORTENING_SERVICES = re.compile(
    r"bit\.ly|goo\.gl|shorte\.st|go2l\.ink|x\.co|ow\.ly|t\.co|tinyurl|"
    r"tr\.im|is\.gd|cli\.gs|yfrog\.com|migre\.me|ff\.im|tiny\.cc|url4\.eu|"
    r"twit\.ac|su\.pr|twurl\.nl|snipurl\.com|short\.to|budurl\.com|"
    r"ping\.fm|post\.ly|just\.as|bkite\.com|snipr\.com|fic\.kr|loopt\.us|"
    r"doiop\.com|short\.ie|kl\.am|wp\.me|rubyurl\.com|om\.ly|to\.ly|"
    r"bit\.do|lnkd\.in|db\.tt|qr\.ae|adf\.ly|cutt\.ly|v\.gd|soo\.gd|s2r\.co",
    re.IGNORECASE,
)

IPV4_RE = re.compile(r"^(?:\d{1,3}\.){3}\d{1,3}$")
IPV4_HEX_RE = re.compile(r"^0x[0-9a-f]+(\.0x[0-9a-f]+){3}$", re.IGNORECASE)


def _ensure_scheme(url: str) -> str:
    """Add a scheme if missing so urlparse splits host/path correctly."""
    if "://" not in url:
        return "http://" + url.strip()
    return url.strip()


def having_IP_Address(url: str) -> int:
    host = urlparse(_ensure_scheme(url)).hostname or ""
    host = host.strip("[]")  # bare IPv6
    if IPV4_RE.match(host) or IPV4_HEX_RE.match(host) or ":" in host:
        return -1
    return 1


def URL_Length(url: str) -> int:
    n = len(url.strip())
    if n < 54:
        return 1
    if n <= 75:
        return 0
    return -1


def Shortining_Service(url: str) -> int:
    return -1 if SHORTENING_SERVICES.search(url) else 1


def having_At_Symbol(url: str) -> int:
    return -1 if "@" in url else 1


def double_slash_redirecting(url: str) -> int:
    # A legitimate "//" only ever appears right after the scheme (http://...).
    # Anything after that position means the path is trying to redirect.
    scheme_end = url.find("://")
    search_from = scheme_end + 3 if scheme_end != -1 else 0
    return -1 if url.find("//", search_from) != -1 else 1


def Prefix_Suffix(url: str) -> int:
    host = urlparse(_ensure_scheme(url)).hostname or ""
    return -1 if "-" in host else 1


def having_Sub_Domain(url: str) -> int:
    host = urlparse(_ensure_scheme(url)).hostname or ""
    if IPV4_RE.match(host):
        return 1
    if host.startswith("www."):
        host = host[4:]
    parts = [p for p in host.split(".") if p]
    dot_count = max(len(parts) - 2, 0)  # subtract the registrable domain + TLD
    if dot_count <= 1:
        return 1
    if dot_count == 2:
        return 0
    return -1


def HTTPS_token(url: str) -> int:
    host = urlparse(_ensure_scheme(url)).hostname or ""
    return -1 if "https" in host.lower() else 1


# Order matters: must match columns.LEXICAL_FEATURES exactly.
EXTRACTORS = {
    "having_IP_Address": having_IP_Address,
    "URL_Length": URL_Length,
    "Shortining_Service": Shortining_Service,
    "having_At_Symbol": having_At_Symbol,
    "double_slash_redirecting": double_slash_redirecting,
    "Prefix_Suffix": Prefix_Suffix,
    "having_Sub_Domain": having_Sub_Domain,
    "HTTPS_token": HTTPS_token,
}


def extract(url: str) -> dict:
    """Return {feature_name: value} for every lexical feature."""
    return {name: fn(url) for name, fn in EXTRACTORS.items()}


if __name__ == "__main__":
    import sys

    test_url = sys.argv[1] if len(sys.argv) > 1 else "http://paypal-secure.login-verify.com/signin"
    for name, value in extract(test_url).items():
        print(f"{name:30s} {value:+d}")
