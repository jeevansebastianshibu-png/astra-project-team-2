"""
Trains and compares 6 classifier families on the full 30-feature dataset,
saves the best model plus EDA / evaluation plots into reports/.

Usage:
    python src/train_full_model.py
"""

import json
import time
from pathlib import Path

import joblib
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from sklearn.ensemble import GradientBoostingClassifier, RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    ConfusionMatrixDisplay,
    accuracy_score,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
)
from sklearn.model_selection import StratifiedKFold, cross_val_score, train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier

from columns import ALL_FEATURES, TARGET

ROOT = Path(__file__).resolve().parent.parent
DATA_PATH = ROOT / "data" / "dataset.csv"
MODELS_DIR = ROOT / "models"
REPORTS_DIR = ROOT / "reports"
MODELS_DIR.mkdir(exist_ok=True)
REPORTS_DIR.mkdir(exist_ok=True)

RANDOM_STATE = 42


def load_data():
    df = pd.read_csv(DATA_PATH)
    X = df[ALL_FEATURES]
    y = df[TARGET]
    return df, X, y


def run_eda(df: pd.DataFrame):
    fig, axes = plt.subplots(1, 2, figsize=(14, 5.5))

    counts = df[TARGET].value_counts().sort_index()
    labels = {-1: "Phishing", 1: "Legitimate"}
    axes[0].bar([labels[i] for i in counts.index], counts.values, color=["#d64545", "#3b8f5c"])
    axes[0].set_title(f"Class balance (n={len(df)})")
    axes[0].set_ylabel("Website count")
    for i, v in enumerate(counts.values):
        axes[0].text(i, v + 50, str(v), ha="center", fontweight="bold")

    corr = df[ALL_FEATURES + [TARGET]].corr()
    sns.heatmap(corr, ax=axes[1], cmap="RdBu_r", center=0, cbar_kws={"shrink": 0.7},
                xticklabels=False, yticklabels=False)
    axes[1].set_title("Feature correlation heatmap (30 features + Result)")

    plt.tight_layout()
    out = REPORTS_DIR / "eda_class_balance_correlation.png"
    plt.savefig(out, dpi=130)
    plt.close()
    print(f"[eda] saved {out}")


def get_models():
    return {
        "Logistic Regression": LogisticRegression(max_iter=2000, random_state=RANDOM_STATE),
        "Decision Tree": DecisionTreeClassifier(random_state=RANDOM_STATE),
        "Random Forest": RandomForestClassifier(n_estimators=200, random_state=RANDOM_STATE, n_jobs=-1),
        "Gradient Boosting": GradientBoostingClassifier(random_state=RANDOM_STATE),
        "K-Nearest Neighbors": KNeighborsClassifier(n_neighbors=7),
        "SVM (RBF kernel)": SVC(kernel="rbf", probability=True, random_state=RANDOM_STATE),
    }


def train_and_compare(X, y):
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, stratify=y, random_state=RANDOM_STATE
    )

    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=RANDOM_STATE)
    results = []
    fitted = {}

    for name, model in get_models().items():
        t0 = time.time()
        model.fit(X_train, y_train)
        preds = model.predict(X_test)
        cv_scores = cross_val_score(model, X_train, y_train, cv=cv, scoring="accuracy", n_jobs=-1)

        row = {
            "Model": name,
            "Test Accuracy": accuracy_score(y_test, preds),
            "Precision": precision_score(y_test, preds, pos_label=1),
            "Recall": recall_score(y_test, preds, pos_label=1),
            "F1-score": f1_score(y_test, preds, pos_label=1),
            "5-fold CV Accuracy": cv_scores.mean(),
            "Train Time (s)": round(time.time() - t0, 2),
        }
        results.append(row)
        fitted[name] = model
        print(f"[train] {name:22s} acc={row['Test Accuracy']:.4f}  f1={row['F1-score']:.4f}")

    results_df = pd.DataFrame(results).sort_values("Test Accuracy", ascending=False).reset_index(drop=True)
    results_df.to_csv(REPORTS_DIR / "model_comparison.csv", index=False)

    best_name = results_df.iloc[0]["Model"]
    best_model = fitted[best_name]
    print(f"\n[best] {best_name} ({results_df.iloc[0]['Test Accuracy']:.4f} test accuracy)")

    # Confusion matrix for the best model
    preds = best_model.predict(X_test)
    cm = confusion_matrix(y_test, preds, labels=[-1, 1])
    disp = ConfusionMatrixDisplay(cm, display_labels=["Phishing", "Legitimate"])
    fig, ax = plt.subplots(figsize=(5, 5))
    disp.plot(ax=ax, cmap="Blues", colorbar=False)
    ax.set_title(f"{best_name} — confusion matrix (test set, n={len(y_test)})")
    plt.tight_layout()
    plt.savefig(REPORTS_DIR / "confusion_matrix.png", dpi=130)
    plt.close()

    # Feature importance (only meaningful for tree-based models)
    if hasattr(best_model, "feature_importances_"):
        importances = pd.Series(best_model.feature_importances_, index=X.columns).sort_values()
        fig, ax = plt.subplots(figsize=(7, 8))
        importances.tail(20).plot(kind="barh", ax=ax, color="#3b6ea5")
        ax.set_title(f"{best_name} — feature importance (top 20 of 30)")
        ax.set_xlabel("Gini importance")
        plt.tight_layout()
        plt.savefig(REPORTS_DIR / "feature_importance.png", dpi=130)
        plt.close()
        importances.sort_values(ascending=False).to_csv(REPORTS_DIR / "feature_importance.csv")

    joblib.dump(best_model, MODELS_DIR / "full_model.pkl")
    with open(MODELS_DIR / "full_model_meta.json", "w") as f:
        json.dump({"model_name": best_name, "features": list(X.columns)}, f, indent=2)

    return results_df, best_name


if __name__ == "__main__":
    df, X, y = load_data()
    print(f"Loaded {len(df)} rows, {len(ALL_FEATURES)} features. "
          f"Class balance: {dict(y.value_counts())}")
    run_eda(df)
    results_df, best_name = train_and_compare(X, y)
    print("\n=== Model comparison ===")
    print(results_df.to_string(index=False))
    print(f"\nSaved best model ({best_name}) to models/full_model.pkl")
